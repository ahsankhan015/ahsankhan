$('.hero-slider').owlCarousel({
    items: 1,
    loop: true,
    margin: 0,
    nav: true,
    dots: true,
    navText: ['<i class="icofont-swoosh-left"></i>', '<i class="icofont-swoosh-right"></i>']
});